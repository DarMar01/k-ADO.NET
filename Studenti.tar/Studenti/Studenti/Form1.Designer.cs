﻿namespace Studenti
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dgvStudenti = new System.Windows.Forms.DataGridView();
            this.txtIme = new System.Windows.Forms.TextBox();
            this.lblIme = new System.Windows.Forms.Label();
            this.lblPrezime = new System.Windows.Forms.Label();
            this.txtPrezime = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.lblGodine = new System.Windows.Forms.Label();
            this.txtGodine = new System.Windows.Forms.TextBox();
            this.btnDodaj = new System.Windows.Forms.Button();
            this.gbx = new System.Windows.Forms.GroupBox();
            this.btnIzmeni = new System.Windows.Forms.Button();
            this.btnIzbrisi = new System.Windows.Forms.Button();
            this.btnOsvezi = new System.Windows.Forms.Button();
            this.gboxListaStudenata = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudenti)).BeginInit();
            this.gbx.SuspendLayout();
            this.gboxListaStudenata.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvStudenti
            // 
            this.dgvStudenti.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvStudenti.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvStudenti.Location = new System.Drawing.Point(13, 25);
            this.dgvStudenti.MultiSelect = false;
            this.dgvStudenti.Name = "dgvStudenti";
            this.dgvStudenti.ReadOnly = true;
            this.dgvStudenti.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvStudenti.Size = new System.Drawing.Size(732, 252);
            this.dgvStudenti.TabIndex = 0;
            // 
            // txtIme
            // 
            this.txtIme.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIme.Location = new System.Drawing.Point(15, 48);
            this.txtIme.Multiline = true;
            this.txtIme.Name = "txtIme";
            this.txtIme.Size = new System.Drawing.Size(148, 34);
            this.txtIme.TabIndex = 0;
            // 
            // lblIme
            // 
            this.lblIme.AutoSize = true;
            this.lblIme.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIme.Location = new System.Drawing.Point(12, 27);
            this.lblIme.Name = "lblIme";
            this.lblIme.Size = new System.Drawing.Size(45, 19);
            this.lblIme.TabIndex = 2;
            this.lblIme.Text = "Ime:";
            // 
            // lblPrezime
            // 
            this.lblPrezime.AutoSize = true;
            this.lblPrezime.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrezime.Location = new System.Drawing.Point(179, 27);
            this.lblPrezime.Name = "lblPrezime";
            this.lblPrezime.Size = new System.Drawing.Size(81, 19);
            this.lblPrezime.TabIndex = 4;
            this.lblPrezime.Text = "Prezime:";
            // 
            // txtPrezime
            // 
            this.txtPrezime.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrezime.Location = new System.Drawing.Point(182, 48);
            this.txtPrezime.Multiline = true;
            this.txtPrezime.Name = "txtPrezime";
            this.txtPrezime.Size = new System.Drawing.Size(222, 34);
            this.txtPrezime.TabIndex = 1;
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEmail.Location = new System.Drawing.Point(523, 27);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(63, 19);
            this.lblEmail.TabIndex = 8;
            this.lblEmail.Text = "EMail:";
            // 
            // txtEmail
            // 
            this.txtEmail.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmail.Location = new System.Drawing.Point(526, 48);
            this.txtEmail.Multiline = true;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(222, 34);
            this.txtEmail.TabIndex = 3;
            // 
            // lblGodine
            // 
            this.lblGodine.AutoSize = true;
            this.lblGodine.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGodine.Location = new System.Drawing.Point(423, 27);
            this.lblGodine.Name = "lblGodine";
            this.lblGodine.Size = new System.Drawing.Size(72, 19);
            this.lblGodine.TabIndex = 6;
            this.lblGodine.Text = "Godine:";
            // 
            // txtGodine
            // 
            this.txtGodine.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGodine.Location = new System.Drawing.Point(426, 48);
            this.txtGodine.Multiline = true;
            this.txtGodine.Name = "txtGodine";
            this.txtGodine.Size = new System.Drawing.Size(71, 34);
            this.txtGodine.TabIndex = 2;
            // 
            // btnDodaj
            // 
            this.btnDodaj.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDodaj.Image = ((System.Drawing.Image)(resources.GetObject("btnDodaj.Image")));
            this.btnDodaj.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDodaj.Location = new System.Drawing.Point(32, 141);
            this.btnDodaj.Name = "btnDodaj";
            this.btnDodaj.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnDodaj.Size = new System.Drawing.Size(156, 47);
            this.btnDodaj.TabIndex = 4;
            this.btnDodaj.Text = "   Dodaj";
            this.btnDodaj.UseVisualStyleBackColor = true;
            // 
            // gbx
            // 
            this.gbx.Controls.Add(this.txtIme);
            this.gbx.Controls.Add(this.lblIme);
            this.gbx.Controls.Add(this.txtEmail);
            this.gbx.Controls.Add(this.lblEmail);
            this.gbx.Controls.Add(this.lblPrezime);
            this.gbx.Controls.Add(this.txtPrezime);
            this.gbx.Controls.Add(this.txtGodine);
            this.gbx.Controls.Add(this.lblGodine);
            this.gbx.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbx.Location = new System.Drawing.Point(17, 14);
            this.gbx.Name = "gbx";
            this.gbx.Size = new System.Drawing.Size(777, 103);
            this.gbx.TabIndex = 10;
            this.gbx.TabStop = false;
            this.gbx.Text = "Unos / Izmena podataka";
            // 
            // btnIzmeni
            // 
            this.btnIzmeni.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzmeni.Image = ((System.Drawing.Image)(resources.GetObject("btnIzmeni.Image")));
            this.btnIzmeni.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIzmeni.Location = new System.Drawing.Point(225, 141);
            this.btnIzmeni.Name = "btnIzmeni";
            this.btnIzmeni.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnIzmeni.Size = new System.Drawing.Size(156, 47);
            this.btnIzmeni.TabIndex = 5;
            this.btnIzmeni.Text = "   Izmeni";
            this.btnIzmeni.UseVisualStyleBackColor = true;
            // 
            // btnIzbrisi
            // 
            this.btnIzbrisi.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnIzbrisi.Image = ((System.Drawing.Image)(resources.GetObject("btnIzbrisi.Image")));
            this.btnIzbrisi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIzbrisi.Location = new System.Drawing.Point(417, 141);
            this.btnIzbrisi.Name = "btnIzbrisi";
            this.btnIzbrisi.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnIzbrisi.Size = new System.Drawing.Size(156, 47);
            this.btnIzbrisi.TabIndex = 6;
            this.btnIzbrisi.Text = "   Izbriši";
            this.btnIzbrisi.UseVisualStyleBackColor = true;
            // 
            // btnOsvezi
            // 
            this.btnOsvezi.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOsvezi.Image = ((System.Drawing.Image)(resources.GetObject("btnOsvezi.Image")));
            this.btnOsvezi.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOsvezi.Location = new System.Drawing.Point(609, 141);
            this.btnOsvezi.Name = "btnOsvezi";
            this.btnOsvezi.Padding = new System.Windows.Forms.Padding(15, 0, 0, 0);
            this.btnOsvezi.Size = new System.Drawing.Size(156, 47);
            this.btnOsvezi.TabIndex = 7;
            this.btnOsvezi.Text = "   Osveži";
            this.btnOsvezi.UseVisualStyleBackColor = true;
            // 
            // gboxListaStudenata
            // 
            this.gboxListaStudenata.Controls.Add(this.dgvStudenti);
            this.gboxListaStudenata.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gboxListaStudenata.Location = new System.Drawing.Point(19, 203);
            this.gboxListaStudenata.Name = "gboxListaStudenata";
            this.gboxListaStudenata.Size = new System.Drawing.Size(774, 291);
            this.gboxListaStudenata.TabIndex = 14;
            this.gboxListaStudenata.TabStop = false;
            this.gboxListaStudenata.Text = "Lista studenata";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 509);
            this.Controls.Add(this.btnOsvezi);
            this.Controls.Add(this.btnIzbrisi);
            this.Controls.Add(this.btnIzmeni);
            this.Controls.Add(this.gbx);
            this.Controls.Add(this.btnDodaj);
            this.Controls.Add(this.gboxListaStudenata);
            this.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Evidencija studenata";
            ((System.ComponentModel.ISupportInitialize)(this.dgvStudenti)).EndInit();
            this.gbx.ResumeLayout(false);
            this.gbx.PerformLayout();
            this.gboxListaStudenata.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvStudenti;
        private System.Windows.Forms.TextBox txtIme;
        private System.Windows.Forms.Label lblIme;
        private System.Windows.Forms.Label lblPrezime;
        private System.Windows.Forms.TextBox txtPrezime;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label lblGodine;
        private System.Windows.Forms.TextBox txtGodine;
        private System.Windows.Forms.Button btnDodaj;
        private System.Windows.Forms.GroupBox gbx;
        private System.Windows.Forms.Button btnIzmeni;
        private System.Windows.Forms.Button btnIzbrisi;
        private System.Windows.Forms.Button btnOsvezi;
        private System.Windows.Forms.GroupBox gboxListaStudenata;
    }
}

